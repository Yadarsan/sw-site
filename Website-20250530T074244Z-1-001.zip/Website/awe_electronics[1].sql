-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2025 at 04:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `awe_electronics`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `name`, `password`, `role`) VALUES
(1, 'admin', '$2y$10$deSB7RLLNvHSoFQjKEI.cexm5OT2z.Ov/HF5P.dsCigAa6QQmdmlu', 'super_admin'),
(2, 'inventory_manager', '$2y$10$deSB7RLLNvHSoFQjKEI.cexm5OT2z.Ov/HF5P.dsCigAa6QQmdmlu', 'manager'),
(3, 'sales_admin', '$2y$10$deSB7RLLNvHSoFQjKEI.cexm5OT2z.Ov/HF5P.dsCigAa6QQmdmlu', 'staff');
(4, 'staff', '$2y$10$RJaRqTeCugb7mWIo51P5HOWgtpj9MlBqUmSMYMh5ohA0u6KEThu9C', 'st')

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`user_id`, `name`, `password`, `email`, `phone`, `address`) VALUES
(1, 'John Smith', '$2y$10$deSB7RLLNvHSoFQjKEI.cexm5OT2z.Ov/HF5P.dsCigAa6QQmdmlu', 'john@example.com', '1234567890', '123 Main St, Sydney, NSW 2000, Australia'),
(2, 'Emma Wilson', '$2y$10$deSB7RLLNvHSoFQjKEI.cexm5OT2z.Ov/HF5P.dsCigAa6QQmdmlu', 'emma@example.com', '0987654321', '456 King St, Melbourne, VIC 3000, Australia'),
(3, 'Michael Brown', '$2y$10$deSB7RLLNvHSoFQjKEI.cexm5OT2z.Ov/HF5P.dsCigAa6QQmdmlu', 'michael@example.com', '5551234567', '789 Queen St, Brisbane, QLD 4000, Australia'),
(4, 'Sarah Johnson', '$2y$10$deSB7RLLNvHSoFQjKEI.cexm5OT2z.Ov/HF5P.dsCigAa6QQmdmlu', 'sarah@example.com', '4445556666', '101 James St, Perth, WA 6000, Australia'),
(5, 'David Lee', '$2y$10$deSB7RLLNvHSoFQjKEI.cexm5OT2z.Ov/HF5P.dsCigAa6QQmdmlu', 'david@example.com', '7778889999', '202 Elizabeth St, Adelaide, SA 5000, Australia'),
(6, 'Kavindu Bopitiya', '$2y$10$RJaRqTeCugb7mWIo51P5HOWgtpj9MlBqUmSMYMh5ohA0u6KEThu9C', 'kavindubopitiya03@gmail.com', '', ''),
(7, 'Range', '$2y$10$lUouIWqJdAHN9JGe.sO8reJBulXOhkOg41CeVcKbDGKTmKy0cuOjG', 'Range@gmail.com', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `invoice_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `date` datetime DEFAULT current_timestamp(),
  `order_details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`invoice_id`, `order_id`, `date`, `order_details`) VALUES
(1, 1, '2023-05-10 14:35:00', '[{\"product_id\":1,\"name\":\"iPhone 13 Pro\",\"quantity\":1,\"unit_price\":1299.99},{\"product_id\":14,\"name\":\"Bose QuietComfort 45\",\"quantity\":1,\"unit_price\":329.99}]'),
(2, 2, '2023-05-15 10:20:00', '[{\"product_id\":6,\"name\":\"MacBook Pro 16\\\"\",\"quantity\":1,\"unit_price\":2499.99},{\"product_id\":18,\"name\":\"Google Nest Hub (2nd Gen)\",\"quantity\":1,\"unit_price\":99.99}]'),
(3, 3, '2023-05-20 16:50:00', '[{\"product_id\":3,\"name\":\"Google Pixel 6\",\"quantity\":1,\"unit_price\":799.99}]'),
(4, 5, '2023-05-28 11:35:00', '[{\"product_id\":13,\"name\":\"Sony 75\\\" LED 4K TV\",\"quantity\":1,\"unit_price\":2199.99}]');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT 'Pending',
  `total_price` decimal(10,2) NOT NULL,
  `shipping_info` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `order_date`, `status`, `total_price`, `shipping_info`) VALUES
(1, 1, '2023-05-10 14:30:00', 'Delivered', 1349.99, '{\"name\":\"John Smith\",\"address\":\"123 Main St\",\"city\":\"Sydney\",\"state\":\"NSW\",\"postal_code\":\"2000\",\"country\":\"Australia\",\"phone\":\"1234567890\"}'),
(2, 2, '2023-05-15 10:15:00', 'Shipped', 2599.98, '{\"name\":\"Emma Wilson\",\"address\":\"456 King St\",\"city\":\"Melbourne\",\"state\":\"VIC\",\"postal_code\":\"3000\",\"country\":\"Australia\",\"phone\":\"0987654321\"}'),
(3, 3, '2023-05-20 16:45:00', 'Processing', 799.99, '{\"name\":\"Michael Brown\",\"address\":\"789 Queen St\",\"city\":\"Brisbane\",\"state\":\"QLD\",\"postal_code\":\"4000\",\"country\":\"Australia\",\"phone\":\"5551234567\"}'),
(4, 4, '2023-05-25 09:00:00', 'Pending', 329.99, '{\"name\":\"Sarah Johnson\",\"address\":\"101 James St\",\"city\":\"Perth\",\"state\":\"WA\",\"postal_code\":\"6000\",\"country\":\"Australia\",\"phone\":\"4445556666\"}'),
(5, 1, '2023-05-28 11:30:00', 'Processing', 2199.99, '{\"name\":\"John Smith\",\"address\":\"123 Main St\",\"city\":\"Sydney\",\"state\":\"NSW\",\"postal_code\":\"2000\",\"country\":\"Australia\",\"phone\":\"1234567890\"}');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`order_id`, `product_id`, `quantity`, `unit_price`) VALUES
(1, 1, 1, 1299.99),
(1, 14, 1, 329.99),
(2, 6, 1, 2499.99),
(2, 18, 1, 99.99),
(3, 3, 1, 799.99),
(4, 14, 1, 329.99),
(5, 13, 1, 2199.99);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `method` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `order_id`, `amount`, `method`, `status`) VALUES
(1, 1, 1349.99, 'Credit Card', 'Completed'),
(2, 2, 2599.98, 'PayPal', 'Completed'),
(3, 3, 799.99, 'Credit Card', 'Completed'),
(4, 4, 329.99, 'Bank Transfer', 'Pending'),
(5, 5, 2199.99, 'Credit Card', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `image_url` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `description`, `price`, `stock`, `category`, `image_url`) VALUES
(1, 'Smart TV 55\"', '4K Ultra HD Smart LED TV', 699.99, 15, 'TV & Audio', NULL),
(2, 'Laptop Pro', '15\" Professional Laptop', 1299.99, 8, 'Computers', NULL),
(3, 'Wireless Headphones', 'Noise Cancelling Bluetooth Headphones', 199.99, 25, 'Audio', NULL),
(4, 'iPhone 13 Pro', 'Latest iPhone with A15 Bionic chip, Pro camera system with 12MP cameras, and 6.1-inch Super Retina XDR display.', 1299.99, 15, 'Smartphones', 'https://i.imgur.com/lzFh0nZ.jpg'),
(5, 'Samsung Galaxy S21', 'Flagship Android phone with Exynos 2100 processor, 8GB RAM, 128GB storage, and triple camera system.', 999.99, 20, 'Smartphones', 'https://i.imgur.com/9FUq5W5.jpg'),
(6, 'Google Pixel 6', 'Features Google Tensor chip, 8GB RAM, 128GB storage, and advanced camera system with computational photography.', 799.99, 10, 'Smartphones', 'https://i.imgur.com/t2MVSQZ.jpg'),
(7, 'OnePlus 9 Pro', 'Premium Android smartphone with Snapdragon 888, 12GB RAM, 256GB storage, and Hasselblad camera system.', 899.99, 8, 'Smartphones', 'https://i.imgur.com/BKfJ5qd.jpg'),
(8, 'Xiaomi Mi 11', 'Flagship phone with Snapdragon 888, 8GB RAM, 128GB storage, and 108MP triple camera system.', 749.99, 12, 'Smartphones', 'https://i.imgur.com/4H6YjP1.jpg'),
(9, 'MacBook Pro 16\"', 'Powerful laptop with M1 Pro/Max chip, up to 64GB unified memory, and up to 8TB SSD storage.', 2499.99, 7, 'Laptops', 'https://i.imgur.com/ZZAGdJi.jpg'),
(10, 'Dell XPS 15', 'Premium Windows laptop with Intel Core i7, 16GB RAM, 512GB SSD, and NVIDIA GeForce RTX 3050 Ti.', 1899.99, 9, 'Laptops', 'https://i.imgur.com/D1Nj8Y6.jpg'),
(11, 'Lenovo ThinkPad X1 Carbon', 'Business laptop with Intel Core i7, 16GB RAM, 1TB SSD, and 14-inch 4K display.', 1799.99, 5, 'Laptops', 'https://i.imgur.com/4WiVJhk.jpg'),
(12, 'HP Spectre x360', 'Convertible laptop with Intel Core i7, 16GB RAM, 1TB SSD, and 13.5-inch OLED touchscreen.', 1599.99, 6, 'Laptops', 'https://i.imgur.com/wHGJ68K.jpg'),
(13, 'ASUS ROG Zephyrus G14', 'Gaming laptop with AMD Ryzen 9, 16GB RAM, 1TB SSD, and NVIDIA GeForce RTX 3060.', 1699.99, 4, 'Laptops', 'https://i.imgur.com/NzCLZuE.jpg'),
(14, 'Samsung 65\" QLED 4K TV', 'Premium 4K QLED smart TV with Quantum HDR, Motion Rate 240, and Tizen OS.', 1799.99, 3, 'TVs & Audio', 'https://i.imgur.com/BNFKFMH.jpg'),
(15, 'LG 55\" OLED 4K TV', 'OLED smart TV with Alpha 9 Gen 4 AI Processor, Dolby Vision IQ, and webOS.', 1499.99, 5, 'TVs & Audio', 'https://i.imgur.com/f0R9gZC.jpg'),
(16, 'Sony 75\" LED 4K TV', 'Large 4K LED smart TV with X1 Ultimate processor, full array LED, and Google TV.', 2199.99, 2, 'TVs & Audio', 'https://i.imgur.com/YvIyvSy.jpg'),
(17, 'Bose QuietComfort 45', 'Premium noise-cancelling headphones with up to 24 hours of battery life and comfortable over-ear design.', 329.99, 15, 'TVs & Audio', 'https://i.imgur.com/EqbDGFL.jpg'),
(18, 'Sony WH-1000XM4', 'Wireless noise-cancelling headphones with 30 hours of battery life and DSEE Extreme audio upscaling.', 349.99, 10, 'TVs & Audio', 'https://i.imgur.com/FUrZNJ8.jpg'),
(19, 'Amazon Echo (4th Gen)', 'Smart speaker with Alexa voice assistant, premium sound, and smart home hub.', 99.99, 25, 'Smart Home', 'https://i.imgur.com/1r9vuzP.jpg'),
(20, 'Google Nest Hub (2nd Gen)', 'Smart display with Google Assistant, 7-inch touchscreen, and sleep sensing.', 99.99, 18, 'Smart Home', 'https://i.imgur.com/XWtAMgc.jpg'),
(21, 'Philips Hue Starter Kit', 'Smart lighting kit with three color bulbs and Hue Bridge for voice and app control.', 199.99, 12, 'Smart Home', 'https://i.imgur.com/sFLTq0A.jpg'),
(22, 'Ring Video Doorbell 4', 'Smart doorbell with 1080p HD video, motion detection, and two-way talk.', 199.99, 14, 'Smart Home', 'https://i.imgur.com/jlDwRKi.jpg'),
(23, 'Nest Learning Thermostat', 'Smart thermostat that learns your preferences and adjusts temperature automatically.', 249.99, 8, 'Smart Home', 'https://i.imgur.com/O0OnzLo.jpg'),
(24, 'Canon EOS R6', 'Full-frame mirrorless camera with 20.1MP CMOS sensor, DIGIC X processor, and 4K video.', 2499.99, 3, 'Cameras', 'https://i.imgur.com/8RctWt7.jpg'),
(25, 'Sony Alpha a7 III', 'Full-frame mirrorless camera with 24.2MP Exmor R CMOS sensor and 4K HDR video.', 1999.99, 4, 'Cameras', 'https://i.imgur.com/QQjZON5.jpg'),
(26, 'Nikon Z6 II', 'Full-frame mirrorless camera with 24.5MP BSI CMOS sensor and dual EXPEED 6 processors.', 1999.99, 2, 'Cameras', 'https://i.imgur.com/1i4DVSu.jpg'),
(27, 'GoPro HERO10 Black', 'Action camera with 5.3K video, 23MP photos, and HyperSmooth 4.0 stabilization.', 499.99, 7, 'Cameras', 'https://i.imgur.com/4reBh9t.jpg'),
(28, 'DJI Air 2S', 'Drone with 1-inch CMOS sensor, 5.4K video, and MasterShots intelligent shooting.', 999.99, 5, 'Cameras', 'https://i.imgur.com/VScj9yt.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`invoice_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `customers` (`user_id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
